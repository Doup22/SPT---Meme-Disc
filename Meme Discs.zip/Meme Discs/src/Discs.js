var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};

Object.defineProperty(exports, "__esModule", { value: true });

const LogTextColor_1 = require("C:/snapshot/project/obj/models/spt/logging/LogTextColor");
const path_1 = __importDefault(require("path"));

class Mod {
    // Pre-load setup - You can log messages for debugging purposes here
    preAkiLoad(container) {
        const logger = container.resolve("WinstonLogger");
        logger.logWithColor("Modifying 20x1mm disk ammo properties", LogTextColor_1.LogTextColor.GREEN);
    }

    // Post DB Load - This is where we modify ammo stats after database load
    postDBLoad(container) {
        const databaseServer = container.resolve("DatabaseServer");
        const tables = databaseServer.getTables();

        // Find the 20x1mm disk ammo template by its ID (replace this with the correct ID for the ammo)
        const ammoTemplate = tables.templates.items["6601546f86889319850bd566"];

        if (ammoTemplate) {
            // Modify damage and penetration values for the ammo
            ammoTemplate._props.Damage = 40; // Adjust damage as needed
            ammoTemplate._props.PenetrationPower = 20; // Adjust penetration power as needed


            const logger = container.resolve("WinstonLogger");
            logger.logWithColor("20x1mm disk ammo properties modified", LogTextColor_1.LogTextColor.CYAN);
        } else {
            const logger = container.resolve("WinstonLogger");
            logger.logWithColor("Ammo template not found", LogTextColor_1.LogTextColor.RED);
        }
    }
}

module.exports = { mod: new Mod() };
